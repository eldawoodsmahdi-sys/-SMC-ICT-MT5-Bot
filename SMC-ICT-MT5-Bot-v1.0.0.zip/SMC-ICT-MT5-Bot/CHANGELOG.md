# Changelog

## [1.0.0] - 2026-11-10

أول تنفيذ كامل (المستودع كان فارغاً إلا من README).

- إضافة EA كامل: اتجاه H1 (EMA50/200 + هيكل)، Liquidity Sweep، BOS/CHOCH/MSS، Order Blocks، FVG، Premium/Discount، تأكيد M15.
- إدارة المخاطر: لوت من مسافة SL الفعلية (0.5%)، حد يومي، خسائر متتالية، فلتر سبريد، حدود الوسيط، منع التكرار.
- فحص DEMO صارم وقفل الرمز (EURUSD) والإطار (M15).
- توثيق: README، CONFIG، TESTING.

**حالة التحقق:** لم تتم الترجمة في MetaEditor ولم يُشغَّل Strategy Tester.
