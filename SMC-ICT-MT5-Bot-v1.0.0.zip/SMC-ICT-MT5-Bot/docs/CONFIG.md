# دليل الإعدادات

## ثوابت مقفلة (في `Config.mqh`، ليست مُدخلات)

| الثابت | القيمة |
|---|---|
| LOCKED_SYMBOL_PREFIX | EURUSD (يُقبل لاحقة الوسيط، ويُتحقق أن العملتين EUR/USD) |
| LOCKED_RISK_PERCENT | 0.5 |
| LOCKED_RR | 2.0 |
| LOCKED_EMA_FAST / SLOW | 50 / 200 (على H1) |
| LOCKED_ENTRY_TF / BIAS_TF | M15 / H1 |
| LOCKED_MAGIC | 20261110 |

## مُدخلات قابلة للتعديل (مع سقوف في الكود)

| المُدخل | الافتراضي | النطاق/السقف | الوصف |
|---|---|---|---|
| InpMaxSpreadPoints | 15 | 1-30 | أقصى سبريد بالنقاط (10 نقاط = 1 بيب) |
| InpMaxOpenPositions | 1 | 1-3 | أقصى صفقات مفتوحة |
| InpDailyLossPercent | 2.0 | 0.1-3.0 | حد الخسارة اليومي % من رصيد بداية اليوم |
| InpMaxConsecLosses | 3 | 0-10 | إيقاف اليوم بعد N خسائر متتالية (0 = معطل) |
| InpDeviationPoints | 20 | 0-50 | أقصى انزلاق |
| InpCommissionPerLot | 0.0 | >=0 | عمولة الدورة الكاملة لكل لوت (تُضاف للمخاطرة) |
| InpSLBufferPoints | 30 | 0-200 | هامش خلف الحد الهيكلي |
| InpMinSLPoints | 60 | 30-500 | رفض الصفقة إن كان SL أضيق |
| InpMaxSLPoints | 350 | حتى 1000 | رفض الصفقة إن كان SL أوسع |
| InpSwingStrength | 3 | 2-6 | عدد الشموع على كل جانب للـ Swing |
| InpScanBars | 400 | 200-1000 | عدد شموع M15 المحللة |
| InpSetupMaxAgeBars | 30 | 10-60 | أقصى عمر للـ Sweep بالشموع |
| InpDisplacementATR | 1.0 | 0.3-3.0 | حد جسم شمعة Displacement |
| InpRequireDisplacement | true | | اشتراط MSS |
| InpUsePDHPDL | true | | اعتبار قمة/قاع أمس سيولة |
| InpFirstTouchOnly | true | | أول إعادة اختبار فقط |
| InpUseH1Structure | true | | عدم تعارض هيكل H1 مع EMA |
| InpVerboseLog | false | | سجلات تشخيصية لكل شمعة |

## افتراضات اتخذتها (لم تكن في المواصفات)

- EMA 50/200 مطبقة على H1 فقط.
- حد أقصى سبريد 1.5 بيب، صفقة واحدة، حد يومي 2%، 3 خسائر متتالية.
- الـ Order Block = كامل مدى الشمعة المعاكسة الأخيرة عند قاع/قمة الحركة.
- الصفقة تُنفَّذ بسعر السوق عند أول tick بعد إغلاق شمعة التأكيد.
