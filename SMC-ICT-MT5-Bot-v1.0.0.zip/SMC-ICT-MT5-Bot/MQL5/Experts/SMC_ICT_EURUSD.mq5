//+------------------------------------------------------------------+
//|                                              SMC_ICT_EURUSD.mq5  |
//|  DEMO-ONLY EURUSD Expert Advisor: SMC / ICT / Price Action.      |
//|  Entry TF: M15 | Bias TF: H1 (EMA50/EMA200 + structure)          |
//|  Risk: 0.5% per trade | Target: 1:2 | Magic: 20261110            |
//+------------------------------------------------------------------+
#property copyright "SMC ICT EURUSD EA"
#property version   "1.00"
#property description "DEMO-ONLY EURUSD SMC/ICT EA. Refuses to trade on non-demo accounts."

#include <SMC_ICT/Config.mqh>
#include <SMC_ICT/Logger.mqh>
#include <SMC_ICT/Types.mqh>
#include <SMC_ICT/Safety.mqh>
#include <SMC_ICT/Structure.mqh>
#include <SMC_ICT/Liquidity.mqh>
#include <SMC_ICT/Zones.mqh>
#include <SMC_ICT/Signal.mqh>
#include <SMC_ICT/Risk.mqh>
#include <SMC_ICT/Execution.mqh>

//--- NOTE: symbol, risk %, RR, timeframes, EMAs and magic are LOCKED
//---       constants (Config.mqh) and intentionally NOT inputs.
input group "=== Limits (clamped by hard caps in code) ==="
input int    InpMaxSpreadPoints    = 15;    // Max spread, points (10 pts = 1 pip). Cap 30
input int    InpMaxOpenPositions   = 1;     // Max open positions. Cap 3
input double InpDailyLossPercent   = 2.0;   // Daily loss limit, % of day-start balance. Cap 3.0
input int    InpMaxConsecLosses    = 3;     // Stop for the day after N losses in a row (0 = off)
input int    InpDeviationPoints    = 20;    // Max slippage, points
input double InpCommissionPerLot   = 0.0;   // Round-turn commission per lot (account currency), added to risk

input group "=== Stop loss (structure based) ==="
input int    InpSLBufferPoints     = 30;    // Buffer beyond structural extreme, points
input int    InpMinSLPoints        = 60;    // Reject setups with SL tighter than this
input int    InpMaxSLPoints        = 350;   // Reject setups with SL wider than this

input group "=== Strategy ==="
input int    InpSwingStrength      = 3;     // Bars each side for swing detection (2-6)
input int    InpScanBars           = 400;   // M15 bars analysed (200-1000)
input int    InpSetupMaxAgeBars    = 30;    // Max bars since liquidity sweep (10-60)
input double InpDisplacementATR    = 1.0;   // Displacement candle body >= x ATR(14)
input bool   InpRequireDisplacement= true;  // Require displacement (MSS) on the break
input bool   InpUsePDHPDL          = true;  // Include previous day high/low as liquidity
input bool   InpFirstTouchOnly     = true;  // Trade only the first retest of the zone
input bool   InpUseH1Structure     = true;  // H1 swing structure must not contradict EMA bias
input bool   InpVerboseLog         = false; // Detailed per-bar diagnostics

SSignal  g_pending;
int      g_retries = 0;

//+------------------------------------------------------------------+
void Config_Apply()
  {
   g_cfg.maxSpreadPoints    = (int)MathMax(1, MathMin(InpMaxSpreadPoints, CAP_MAX_SPREAD_POINTS));
   g_cfg.maxOpenPositions   = (int)MathMax(1, MathMin(InpMaxOpenPositions, CAP_MAX_POSITIONS));
   g_cfg.dailyLossPercent   = MathMax(0.1, MathMin(InpDailyLossPercent, CAP_DAILY_LOSS_PERCENT));
   g_cfg.maxConsecLosses    = (int)MathMax(0, MathMin(InpMaxConsecLosses, 10));
   g_cfg.deviationPoints    = (int)MathMax(0, MathMin(InpDeviationPoints, 50));
   g_cfg.commissionPerLot   = MathMax(0.0, InpCommissionPerLot);

   g_cfg.slBufferPoints     = (int)MathMax(0, MathMin(InpSLBufferPoints, 200));
   g_cfg.minSlPoints        = (int)MathMax(30, MathMin(InpMinSLPoints, 500));
   g_cfg.maxSlPoints        = (int)MathMax(g_cfg.minSlPoints + 10, MathMin(InpMaxSLPoints, 1000));

   g_cfg.swingStrength      = (int)MathMax(2, MathMin(InpSwingStrength, 6));
   g_cfg.scanBars           = (int)MathMax(200, MathMin(InpScanBars, 1000));
   g_cfg.setupMaxAgeBars    = (int)MathMax(10, MathMin(InpSetupMaxAgeBars, 60));
   g_cfg.displacementAtr    = MathMax(0.3, MathMin(InpDisplacementATR, 3.0));
   g_cfg.requireDisplacement= InpRequireDisplacement;
   g_cfg.usePdhPdl          = InpUsePDHPDL;
   g_cfg.firstTouchOnly     = InpFirstTouchOnly;
   g_cfg.useH1Structure     = InpUseH1Structure;
   g_cfg.verbose            = InpVerboseLog;
  }

//+------------------------------------------------------------------+
int OnInit()
  {
   Config_Apply();

   string why;
   if(!Safety_Startup(why))
     {
      LogError("INIT REFUSED: " + why);
      Alert(SMC_EA_NAME, ": ", why);
      return(INIT_FAILED);
     }
   if(!Signal_Init())
      return(INIT_FAILED);

   Exec_Init();
   if(MQLInfoInteger(MQL_TESTER))
      Signal_ResetState();
   ZeroMemory(g_pending);

   LogInfo(StringFormat("v%s started on %s M15 | DEMO verified | risk %.2f%% | RR 1:%.0f | magic %d",
                        SMC_VERSION, _Symbol, LOCKED_RISK_PERCENT, LOCKED_RR, LOCKED_MAGIC));
   LogInfo(StringFormat("Limits: spread<=%d pts, positions<=%d, daily loss<=%.1f%%, consec losses<=%d, SL %d-%d pts",
                        g_cfg.maxSpreadPoints, g_cfg.maxOpenPositions, g_cfg.dailyLossPercent,
                        g_cfg.maxConsecLosses, g_cfg.minSlPoints, g_cfg.maxSlPoints));
   if(!Safety_TradeAllowed(why))
      LogWarn("Trading currently not possible: " + why);
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   Signal_Deinit();
   LogInfo(StringFormat("Stopped (reason %d).", reason));
  }

//+------------------------------------------------------------------+
//| Once per new M15 bar: safety -> limits -> bias -> setup          |
//+------------------------------------------------------------------+
void Bot_OnNewBar()
  {
   string why;
   if(!Safety_Runtime(why))
     {
      LogWarn("Skipping bar: " + why);
      return;
     }

   if(Risk_CountPositions() >= g_cfg.maxOpenPositions)
     {
      LogDebug("Max open positions reached.");
      return;
     }

   if(Risk_DailyLimitHit(why))
     {
      static datetime lastLoggedDay = 0;
      datetime day = Risk_DayStart();
      if(day != lastLoggedDay)
        {
         LogWarn("TRADING BLOCKED for today: " + why);
         lastLoggedDay = day;
        }
      return;
     }

   string info;
   int bias = Signal_H1Bias(info);
   LogDebug(info);
   if(bias == 0)
      return;

   SSignal sig;
   if(!Signal_Detect(bias, sig))
     {
      LogDebug("No valid setup this bar.");
      return;
     }

   g_pending = sig;
   LogInfo(StringFormat("SIGNAL %s | %s sweep @ %.5f | %s%s (%d bars ago) | %s zone [%.5f - %.5f] | range [%.5f - %.5f] | invalidation %.5f",
                        Signal_DirName(sig.dir), Signal_SrcName(sig.sweepSrc, sig.dir), sig.sweptLevel,
                        Signal_BreakName(sig.breakType), (sig.displacement ? "+MSS" : ""), sig.breakAge,
                        Signal_ZoneName(sig.zoneType), sig.zoneLow, sig.zoneHigh,
                        sig.rangeLow, sig.rangeHigh, sig.invalidation));
  }

//+------------------------------------------------------------------+
//| Every tick while a signal is pending for the current bar         |
//+------------------------------------------------------------------+
void Bot_ExecutePending()
  {
   string why;
   if(!Safety_Quick(why))
     {
      LogWarn("Pending signal dropped: " + why);
      g_pending.valid = false;
      return;
     }
   if(Risk_CountPositions() >= g_cfg.maxOpenPositions)
     {
      g_pending.valid = false;
      return;
     }

   int res = Exec_TryOpen(g_pending, why);
   if(res == EXEC_OK)
     {
      Signal_MarkTraded(g_pending.dir, g_pending.sweepTime);
      g_pending.valid = false;
      return;
     }
   if(res == EXEC_RETRY)
     {
      static datetime lastWarnBar = 0;
      if(g_pending.detectBar != lastWarnBar)
        {
         LogWarn("Waiting (will retry this bar): " + why);
         lastWarnBar = g_pending.detectBar;
        }
      if(StringFind(why, "Order failed") == 0)
        {
         g_retries++;
         if(g_retries >= 3)
           {
            LogWarn("Too many order retries - signal dropped.");
            g_pending.valid = false;
           }
        }
      return;
     }
   LogWarn("Setup rejected: " + why);
   g_pending.valid = false;
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   static datetime lastBar = 0;
   datetime cur = iTime(_Symbol, LOCKED_ENTRY_TF, 0);
   if(cur == 0)
      return;

   if(cur != lastBar)
     {
      lastBar = cur;
      g_pending.valid = false;
      g_retries = 0;
      Bot_OnNewBar();
     }

   if(g_pending.valid)
      Bot_ExecutePending();
  }
//+------------------------------------------------------------------+
