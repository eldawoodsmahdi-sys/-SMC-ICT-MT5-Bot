//+------------------------------------------------------------------+
//|                                                     Zones.mqh    |
//|  Order Blocks and Fair Value Gaps (series-order arrays).         |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_ZONES_MQH
#define SMC_ICT_ZONES_MQH

//+------------------------------------------------------------------+
//| Order block: last opposite-colour candle at/just before the      |
//| impulse-leg extreme. dir>0 -> last bearish candle (demand OB).   |
//+------------------------------------------------------------------+
bool Zone_FindOB(const MqlRates &r[], const int total, const int dir,
                 const int legShift, const int breakShift, SZone &z)
  {
   z.valid = false;
   int pick = legShift;
   for(int j = legShift; j <= legShift + 3 && j < total; j++)
     {
      bool opposite = (dir > 0) ? (r[j].close < r[j].open)
                                : (r[j].close > r[j].open);
      if(opposite)
        { pick = j; break; }
     }
   z.low       = r[pick].low;
   z.high      = r[pick].high;
   z.type      = 1;
   z.formShift = breakShift;
   z.valid     = (z.high > z.low);
   return(z.valid);
  }

//+------------------------------------------------------------------+
//| Fair value gap inside the impulse leg (3-candle imbalance).      |
//| Candles: a = i+1 (older), b = i, c = i-1 (newer).                |
//| Bullish: high[a] < low[c]; bearish: low[a] > high[c].            |
//+------------------------------------------------------------------+
bool Zone_FindFVG(const MqlRates &r[], const int dir, const int legShift,
                  const int breakShift, SZone &z)
  {
   z.valid = false;
   const double minH = FVG_MIN_POINTS * _Point;

   for(int i = legShift - 1; i >= breakShift + 1 && i >= 2; i--)
     {
      double gl, gh;
      if(dir > 0)
        { gl = r[i + 1].high; gh = r[i - 1].low; }
      else
        { gl = r[i - 1].high; gh = r[i + 1].low; }

      if(gh - gl >= minH)
        {
         z.low       = gl;
         z.high      = gh;
         z.type      = 2;
         z.formShift = i - 1;
         z.valid     = true;
         return(true);
        }
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Did any bar in [toShift .. fromShift] trade into the zone?       |
//| (fromShift is the OLDER bar, toShift the newer one)              |
//+------------------------------------------------------------------+
bool Zone_TouchedBetween(const MqlRates &r[], const int dir, const SZone &z,
                         const int fromShift, const int toShift)
  {
   for(int k = fromShift; k >= toShift; k--)
     {
      if(k < 0)
         continue;
      if((dir > 0 && r[k].low <= z.high) || (dir < 0 && r[k].high >= z.low))
         return(true);
     }
   return(false);
  }

#endif
