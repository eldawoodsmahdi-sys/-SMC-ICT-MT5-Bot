//+------------------------------------------------------------------+
//|                                                    Config.mqh    |
//|  Locked (non-negotiable) constants + runtime settings container. |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_CONFIG_MQH
#define SMC_ICT_CONFIG_MQH

#define SMC_VERSION            "1.0.0"
#define SMC_EA_NAME            "SMC_ICT_EURUSD"

//--- LOCKED SETTINGS: approved specification. NEVER change these. ---
#define LOCKED_SYMBOL_PREFIX   "EURUSD"
#define LOCKED_BASE_CCY        "EUR"
#define LOCKED_QUOTE_CCY       "USD"
#define LOCKED_RISK_PERCENT    0.5
#define LOCKED_RR              2.0
#define LOCKED_EMA_FAST        50
#define LOCKED_EMA_SLOW        200
#define LOCKED_ENTRY_TF        PERIOD_M15
#define LOCKED_BIAS_TF         PERIOD_H1
#define LOCKED_MAGIC           20261110

//--- Hard caps applied to adjustable inputs (inputs are clamped) ---
#define CAP_MAX_SPREAD_POINTS  30
#define CAP_MAX_POSITIONS      3
#define CAP_DAILY_LOSS_PERCENT 3.0
#define CAP_MAX_LOTS           5.0

//--- Data requirements ---
#define MIN_BARS_ENTRY         600
#define MIN_BARS_BIAS          400
#define MIN_SCAN_BARS          200

//--- Strategy constants ---
#define LIQ_MAX_POOL_AGE       200   // max age (bars) of a swing liquidity pool
#define REF_MAX_DISTANCE       80    // max distance (bars) sweep -> reference swing
#define FVG_MIN_POINTS         10    // minimum FVG height in points
#define ATR_PERIOD             14

//+------------------------------------------------------------------+
//| Runtime settings (filled from inputs, clamped, in OnInit)        |
//+------------------------------------------------------------------+
struct SSettings
  {
   int    maxSpreadPoints;
   int    maxOpenPositions;
   double dailyLossPercent;
   int    maxConsecLosses;
   int    slBufferPoints;
   int    minSlPoints;
   int    maxSlPoints;
   int    deviationPoints;
   double commissionPerLot;
   int    swingStrength;
   int    scanBars;
   int    setupMaxAgeBars;
   double displacementAtr;
   bool   requireDisplacement;
   bool   usePdhPdl;
   bool   firstTouchOnly;
   bool   useH1Structure;
   bool   verbose;
  };

SSettings g_cfg;

#endif
