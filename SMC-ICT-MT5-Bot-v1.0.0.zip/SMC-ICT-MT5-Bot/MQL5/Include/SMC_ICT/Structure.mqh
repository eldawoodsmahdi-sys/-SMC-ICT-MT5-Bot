//+------------------------------------------------------------------+
//|                                                  Structure.mqh   |
//|  Swing detection, HH/HL/LH/LL trend, ATR helper.                 |
//|  All price arrays are in SERIES order (index 0 = forming bar).   |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_STRUCTURE_MQH
#define SMC_ICT_STRUCTURE_MQH

//+------------------------------------------------------------------+
//| Collect confirmed fractal swings, ordered OLDEST -> NEWEST.      |
//| A swing at index i needs n bars on each side; the forming bar    |
//| (index 0) is never used. Consecutive same-type swings are merged |
//| keeping the extreme, so highs and lows strictly alternate.       |
//+------------------------------------------------------------------+
int Struct_CollectSwings(const MqlRates &r[], const int total, const int n, SSwing &out[])
  {
   ArrayResize(out, 0);
   if(n < 1 || total < (2 * n) + 3)
      return(0);

   for(int i = total - n - 1; i >= n + 1; i--)
     {
      bool isH = true;
      bool isL = true;
      for(int k = 1; k <= n; k++)
        {
         if(!(r[i].high > r[i - k].high && r[i].high >= r[i + k].high))
            isH = false;
         if(!(r[i].low < r[i - k].low && r[i].low <= r[i + k].low))
            isL = false;
         if(!isH && !isL)
            break;
        }
      if(isH == isL)
         continue;                 // no swing, or ambiguous outside bar

      SSwing s;
      s.shift = i;
      s.time  = r[i].time;
      s.dir   = isH ? 1 : -1;
      s.price = isH ? r[i].high : r[i].low;

      int c = ArraySize(out);
      if(c > 0 && out[c - 1].dir == s.dir)
        {
         if((s.dir > 0 && s.price > out[c - 1].price) ||
            (s.dir < 0 && s.price < out[c - 1].price))
            out[c - 1] = s;
        }
      else
        {
         ArrayResize(out, c + 1);
         out[c] = s;
        }
     }
   return(ArraySize(out));
  }

//+------------------------------------------------------------------+
//| Market structure from the last two swing highs and last two      |
//| swing lows that are OLDER than bar 'minShift' (shift > minShift).|
//| Returns +1 (HH + HL), -1 (LH + LL), 0 (range / transition /      |
//| not enough swings).                                              |
//+------------------------------------------------------------------+
int Struct_Trend(const SSwing &sw[], const int minShift, string &label)
  {
   double hi1 = 0.0, hi0 = 0.0, lo1 = 0.0, lo0 = 0.0;
   int nh = 0, nl = 0;

   for(int i = ArraySize(sw) - 1; i >= 0 && (nh < 2 || nl < 2); i--)
     {
      if(sw[i].shift <= minShift)
         continue;
      if(sw[i].dir > 0 && nh < 2)
        {
         if(nh == 0) hi1 = sw[i].price; else hi0 = sw[i].price;
         nh++;
        }
      else if(sw[i].dir < 0 && nl < 2)
        {
         if(nl == 0) lo1 = sw[i].price; else lo0 = sw[i].price;
         nl++;
        }
     }

   label = "N/A";
   if(nh < 2 || nl < 2)
      return(0);

   bool hh = (hi1 > hi0);
   bool hl = (lo1 > lo0);
   if(hh && hl)   { label = "HH+HL"; return(1); }
   if(!hh && !hl) { label = "LH+LL"; return(-1); }
   label = hh ? "HH+LL" : "LH+HL";
   return(0);
  }

//+------------------------------------------------------------------+
//| Simple-average ATR at a given shift (computed from rates, so no  |
//| indicator handle is needed). Returns 0 if not enough data.       |
//+------------------------------------------------------------------+
double Struct_AtrAt(const MqlRates &r[], const int total, const int shift, const int period)
  {
   if(shift < 1 || shift + period + 1 >= total)
      return(0.0);
   double sum = 0.0;
   for(int k = shift; k < shift + period; k++)
     {
      double pc = r[k + 1].close;
      double tr = MathMax(r[k].high - r[k].low,
                          MathMax(MathAbs(r[k].high - pc), MathAbs(r[k].low - pc)));
      sum += tr;
     }
   return(sum / period);
  }

#endif
