//+------------------------------------------------------------------+
//|                                                    Logger.mqh    |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_LOGGER_MQH
#define SMC_ICT_LOGGER_MQH

void LogInfo(const string msg)
  {
   Print("[", SMC_EA_NAME, "] ", msg);
  }

void LogWarn(const string msg)
  {
   Print("[", SMC_EA_NAME, "][WARN] ", msg);
  }

void LogError(const string msg)
  {
   Print("[", SMC_EA_NAME, "][ERROR] ", msg);
  }

void LogDebug(const string msg)
  {
   if(g_cfg.verbose)
      Print("[", SMC_EA_NAME, "][DBG] ", msg);
  }

#endif
