//+------------------------------------------------------------------+
//|                                                     Types.mqh    |
//|  Shared data structures (no string members: safe to copy).       |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_TYPES_MQH
#define SMC_ICT_TYPES_MQH

//--- Confirmed swing point (fractal) ---
struct SSwing
  {
   int      shift;    // bar shift at scan time (series order, 0 = forming bar)
   datetime time;
   double   price;
   int      dir;      // +1 swing high, -1 swing low
  };

//--- Point-of-interest zone (order block or fair value gap) ---
struct SZone
  {
   bool     valid;
   double   low;
   double   high;
   int      type;       // 1 = Order Block, 2 = Fair Value Gap
   int      formShift;  // shift of the newest bar that formed/confirmed the zone
  };

//--- Trade signal produced by the setup engine ---
struct SSignal
  {
   bool     valid;
   int      dir;            // +1 buy, -1 sell
   datetime detectBar;      // open time of the bar on which it was detected
   datetime sweepTime;      // time of liquidity-sweep bar (setup identity key)
   double   sweptLevel;
   int      sweepSrc;       // 1 = swing pool, 2 = previous day high/low
   int      breakType;      // 1 = CHOCH, 2 = BOS, 3 = range break
   bool     displacement;   // true -> structure break is an MSS (with displacement)
   double   invalidation;   // structural extreme (leg low for buys / leg high for sells)
   double   zoneLow;
   double   zoneHigh;
   int      zoneType;
   double   rangeLow;
   double   rangeHigh;
   int      breakAge;       // bars since the structure break
  };

#endif
