//+------------------------------------------------------------------+
//|                                                      Risk.mqh    |
//|  Position limits, daily loss protection, lot sizing (0.5% max),  |
//|  broker stop/volume validation.                                  |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_RISK_MQH
#define SMC_ICT_RISK_MQH

//--- number of open positions owned by this EA on this symbol
int Risk_CountPositions()
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong t = PositionGetTicket(i);
      if(t == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((long)PositionGetInteger(POSITION_MAGIC) != LOCKED_MAGIC)
         continue;
      c++;
     }
   return(c);
  }

//--- server-time start of the current day
datetime Risk_DayStart()
  {
   MqlDateTime t;
   TimeToStruct(TimeCurrent(), t);
   t.hour = 0;
   t.min  = 0;
   t.sec  = 0;
   return(StructToTime(t));
  }

struct SDayStats
  {
   double realized;       // closed P/L today (all deals on the account)
   double floating;       // open P/L now
   int    consecLosses;   // trailing losing closes of this EA today
   double startBalance;   // balance at start of day (approx.)
  };

bool Risk_DayStats(SDayStats &st)
  {
   st.realized     = 0.0;
   st.floating     = AccountInfoDouble(ACCOUNT_PROFIT);
   st.consecLosses = 0;
   st.startBalance = 0.0;

   if(!HistorySelect(Risk_DayStart(), TimeCurrent() + 60))
      return(false);

   int total = HistoryDealsTotal();
   for(int i = 0; i < total; i++)
     {
      ulong tk = HistoryDealGetTicket(i);
      if(tk == 0)
         continue;
      long type = HistoryDealGetInteger(tk, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL)
         continue;

      double pl = HistoryDealGetDouble(tk, DEAL_PROFIT)
                + HistoryDealGetDouble(tk, DEAL_COMMISSION)
                + HistoryDealGetDouble(tk, DEAL_SWAP)
                + HistoryDealGetDouble(tk, DEAL_FEE);
      st.realized += pl;

      long entry = HistoryDealGetInteger(tk, DEAL_ENTRY);
      bool isClose = (entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY);
      if(isClose &&
         HistoryDealGetString(tk, DEAL_SYMBOL) == _Symbol &&
         HistoryDealGetInteger(tk, DEAL_MAGIC) == LOCKED_MAGIC)
        {
         if(pl < 0.0) st.consecLosses++;
         else         st.consecLosses = 0;
        }
     }
   st.startBalance = AccountInfoDouble(ACCOUNT_BALANCE) - st.realized;
   return(true);
  }

//--- true = trading must be blocked (fail-safe: blocks if data unavailable)
bool Risk_DailyLimitHit(string &why)
  {
   SDayStats st;
   if(!Risk_DayStats(st))
     { why = "Deal history unavailable - blocking (fail-safe)."; return(true); }
   if(st.startBalance <= 0.0)
     { why = "Start-of-day balance not positive - blocking."; return(true); }

   double pl    = st.realized + st.floating;
   double limit = st.startBalance * g_cfg.dailyLossPercent / 100.0;
   if(pl <= -limit)
     {
      why = StringFormat("Daily loss limit hit: %.2f <= -%.2f (%.2f%% of %.2f)",
                         pl, limit, g_cfg.dailyLossPercent, st.startBalance);
      return(true);
     }
   if(g_cfg.maxConsecLosses > 0 && st.consecLosses >= g_cfg.maxConsecLosses)
     {
      why = StringFormat("%d consecutive losses today (limit %d).", st.consecLosses, g_cfg.maxConsecLosses);
      return(true);
     }
   return(false);
  }

//--- round lots DOWN to the broker volume step
double Risk_NormalizeLots(const double lots)
  {
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(step <= 0.0 || lots <= 0.0)
      return(0.0);
   double v = MathFloor(lots / step) * step;
   int digits = 0;
   double t = step;
   while(digits < 8 && MathAbs(t - MathRound(t)) > 1e-9)
     { t *= 10.0; digits++; }
   return(NormalizeDouble(v, digits));
  }

//+------------------------------------------------------------------+
//| Lot size so that the loss at SL never exceeds LOCKED_RISK_PERCENT|
//| of min(balance, equity). Lots are rounded DOWN; if even the      |
//| minimum lot would exceed the risk, the trade is refused.         |
//+------------------------------------------------------------------+
bool Risk_CalcLots(const int dir, const double entry, const double sl,
                   double &lots, double &riskMoney, double &riskPct, string &why)
  {
   lots = 0.0;
   riskMoney = 0.0;
   riskPct = 0.0;

   double base = MathMin(AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY));
   if(base <= 0.0)
     { why = "Non-positive balance/equity."; return(false); }
   double allowed = base * LOCKED_RISK_PERCENT / 100.0;

   ENUM_ORDER_TYPE ot = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;

   // loss for 1.0 lot between entry and SL
   double p1 = 0.0;
   double lossPerLot = 0.0;
   if(OrderCalcProfit(ot, _Symbol, 1.0, entry, sl, p1) && p1 < 0.0)
      lossPerLot = MathAbs(p1);
   else
     {
      double ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
      double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
      if(tv <= 0.0)
         tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
      if(ts <= 0.0 || tv <= 0.0)
        { why = "Cannot determine tick value."; return(false); }
      lossPerLot = MathAbs(entry - sl) / ts * tv;
     }
   lossPerLot += g_cfg.commissionPerLot;
   if(lossPerLot <= 0.0)
     { why = "Loss per lot is zero - invalid SL."; return(false); }

   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);

   double v = Risk_NormalizeLots(allowed / lossPerLot);
   if(v < minLot || v <= 0.0)
     {
      why = StringFormat("Min lot %.2f would risk more than %.2f%% (allowed %.2f, per-lot loss %.2f).",
                         minLot, LOCKED_RISK_PERCENT, allowed, lossPerLot);
      return(false);
     }
   v = MathMin(v, MathMin(maxLot, CAP_MAX_LOTS));

   double actual = v * lossPerLot;
   double pct    = actual / base * 100.0;
   if(pct > LOCKED_RISK_PERCENT + 1e-6)
     { why = StringFormat("Computed risk %.4f%% exceeds %.2f%% - refused.", pct, LOCKED_RISK_PERCENT); return(false); }

   double margin = 0.0;
   if(OrderCalcMargin(ot, _Symbol, v, entry, margin))
     {
      if(margin > AccountInfoDouble(ACCOUNT_MARGIN_FREE) * 0.9)
        { why = StringFormat("Insufficient free margin (%.2f needed).", margin); return(false); }
     }

   lots = v;
   riskMoney = actual;
   riskPct = pct;
   return(true);
  }

//+------------------------------------------------------------------+
//| Broker stop-distance validation + SL size sanity limits.         |
//+------------------------------------------------------------------+
bool Risk_ValidateStops(const int dir, const double bid, const double ask,
                        const double entry, const double sl, const double tp, string &why)
  {
   long stopsLvl = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   long freezeLvl = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_FREEZE_LEVEL);
   double minDist = (double)MathMax(stopsLvl, freezeLvl) * _Point;

   if(dir > 0)
     {
      if(!(sl < entry && tp > entry)) { why = "SL/TP on the wrong side of entry (buy)."; return(false); }
      if(bid - sl < minDist)          { why = "SL closer than broker stop level."; return(false); }
      if(tp - bid < minDist)          { why = "TP closer than broker stop level."; return(false); }
     }
   else
     {
      if(!(sl > entry && tp < entry)) { why = "SL/TP on the wrong side of entry (sell)."; return(false); }
      if(sl - ask < minDist)          { why = "SL closer than broker stop level."; return(false); }
      if(ask - tp < minDist)          { why = "TP closer than broker stop level."; return(false); }
     }

   double slDist = MathAbs(entry - sl);
   if(slDist < g_cfg.minSlPoints * _Point)
     { why = StringFormat("SL too tight: %.0f pts < min %d pts.", slDist / _Point, g_cfg.minSlPoints); return(false); }
   if(slDist > g_cfg.maxSlPoints * _Point)
     { why = StringFormat("SL too wide: %.0f pts > max %d pts.", slDist / _Point, g_cfg.maxSlPoints); return(false); }
   return(true);
  }

#endif
