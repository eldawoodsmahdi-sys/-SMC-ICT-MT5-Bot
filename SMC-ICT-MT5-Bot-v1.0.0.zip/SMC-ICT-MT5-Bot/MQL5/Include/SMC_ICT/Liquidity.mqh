//+------------------------------------------------------------------+
//|                                                  Liquidity.mqh   |
//|  Buy-side / sell-side liquidity pools and sweep detection.       |
//|  dir > 0 : look for a SELL-side sweep (swing low / PDL), for BUYs|
//|  dir < 0 : look for a BUY-side sweep (swing high / PDH), for SELLs|
//+------------------------------------------------------------------+
#ifndef SMC_ICT_LIQUIDITY_MQH
#define SMC_ICT_LIQUIDITY_MQH

//+------------------------------------------------------------------+
//| Did closed bar 's' sweep an untouched liquidity pool?            |
//| Sweep = wick beyond the pool AND close back on the original side.|
//| src: 1 = swing pool, 2 = previous-day high/low.                  |
//+------------------------------------------------------------------+
bool Liq_FindSweep(const MqlRates &r[], const int total, const SSwing &sw[],
                   const int dir, const int s, double &level, int &src)
  {
   const int n = g_cfg.swingStrength;

   //--- 1) swing pools (newest first)
   for(int i = ArraySize(sw) - 1; i >= 0; i--)
     {
      if(sw[i].dir != -dir)
         continue;
      if(sw[i].shift < s + n)            // not yet confirmed at bar s
         continue;
      if(sw[i].shift - s > LIQ_MAX_POOL_AGE)
         break;

      double lv = sw[i].price;

      // pool must be untouched between its formation and bar s
      bool taken = false;
      for(int k = sw[i].shift - 1; k > s; k--)
        {
         if((dir > 0 && r[k].low <= lv) || (dir < 0 && r[k].high >= lv))
           { taken = true; break; }
        }
      if(taken)
         continue;

      bool swept = (dir > 0) ? (r[s].low < lv && r[s].close > lv)
                             : (r[s].high > lv && r[s].close < lv);
      if(swept)
        {
         level = lv;
         src   = 1;
         return(true);
        }
     }

   //--- 2) previous day high / low
   if(g_cfg.usePdhPdl)
     {
      int d = iBarShift(_Symbol, PERIOD_D1, r[s].time, false);
      if(d >= 0)
        {
         double pd = (dir > 0) ? iLow(_Symbol, PERIOD_D1, d + 1)
                               : iHigh(_Symbol, PERIOD_D1, d + 1);
         datetime dayStart = iTime(_Symbol, PERIOD_D1, d);
         if(pd > 0.0 && dayStart > 0)
           {
            bool taken = false;
            for(int k = s + 1; k < total && r[k].time >= dayStart; k++)
              {
               if((dir > 0 && r[k].low <= pd) || (dir < 0 && r[k].high >= pd))
                 { taken = true; break; }
              }
            bool swept = (dir > 0) ? (r[s].low < pd && r[s].close > pd)
                                   : (r[s].high > pd && r[s].close < pd);
            if(!taken && swept)
              {
               level = pd;
               src   = 2;
               return(true);
              }
           }
        }
     }
   return(false);
  }

#endif
