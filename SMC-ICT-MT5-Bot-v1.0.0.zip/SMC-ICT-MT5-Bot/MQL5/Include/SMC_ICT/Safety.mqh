//+------------------------------------------------------------------+
//|                                                    Safety.mqh    |
//|  DEMO verification, symbol/timeframe lock, permissions, data.    |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_SAFETY_MQH
#define SMC_ICT_SAFETY_MQH

//--- EURUSD only (broker suffixes allowed, base/quote currency verified)
bool Safety_IsLockedSymbol()
  {
   if(StringFind(_Symbol, LOCKED_SYMBOL_PREFIX) != 0)
      return(false);
   string base   = SymbolInfoString(_Symbol, SYMBOL_CURRENCY_BASE);
   string profit = SymbolInfoString(_Symbol, SYMBOL_CURRENCY_PROFIT);
   return(base == LOCKED_BASE_CCY && profit == LOCKED_QUOTE_CCY);
  }

//--- Strict DEMO verification: real AND contest accounts are refused
bool Safety_IsDemoAccount()
  {
   return(AccountInfoInteger(ACCOUNT_TRADE_MODE) == ACCOUNT_TRADE_MODE_DEMO);
  }

//--- Startup checks that must never fail
bool Safety_Startup(string &why)
  {
   if(!Safety_IsLockedSymbol())
     {
      why = StringFormat("Symbol %s is not EURUSD. This EA trades EURUSD only.", _Symbol);
      return(false);
     }
   if(Period() != LOCKED_ENTRY_TF)
     {
      why = "Attach the EA to an M15 chart (entry timeframe is locked to M15).";
      return(false);
     }
   if(!Safety_IsDemoAccount())
     {
      why = "Account is NOT a verified DEMO account. Trading refused.";
      return(false);
     }
   return(true);
  }

//--- Terminal / account / symbol permissions
bool Safety_TradeAllowed(string &why)
  {
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
     { why = "Algo trading is disabled in the terminal."; return(false); }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
     { why = "Algo trading is not allowed for this EA."; return(false); }
   if(!AccountInfoInteger(ACCOUNT_TRADE_ALLOWED))
     { why = "Trading is not allowed on this account."; return(false); }
   if(!AccountInfoInteger(ACCOUNT_TRADE_EXPERT))
     { why = "Expert trading is not allowed on this account."; return(false); }
   if(SymbolInfoInteger(_Symbol, SYMBOL_TRADE_MODE) != SYMBOL_TRADE_MODE_FULL)
     { why = "Symbol trade mode is not FULL (market closed or restricted)."; return(false); }
   return(true);
  }

//--- Insufficient-history protection
bool Safety_History(string &why)
  {
   if(!(bool)SeriesInfoInteger(_Symbol, LOCKED_ENTRY_TF, SERIES_SYNCHRONIZED))
     { why = "M15 series not synchronized yet."; return(false); }
   if(!(bool)SeriesInfoInteger(_Symbol, LOCKED_BIAS_TF, SERIES_SYNCHRONIZED))
     { why = "H1 series not synchronized yet."; return(false); }
   int bEntry = Bars(_Symbol, LOCKED_ENTRY_TF);
   int bBias  = Bars(_Symbol, LOCKED_BIAS_TF);
   if(bEntry < MIN_BARS_ENTRY)
     { why = StringFormat("Insufficient M15 history: %d < %d bars.", bEntry, MIN_BARS_ENTRY); return(false); }
   if(bBias < MIN_BARS_BIAS)
     { why = StringFormat("Insufficient H1 history: %d < %d bars.", bBias, MIN_BARS_BIAS); return(false); }
   return(true);
  }

//--- Full check, once per new bar
bool Safety_Runtime(string &why)
  {
   if(!Safety_Startup(why))      return(false);
   if(!Safety_TradeAllowed(why)) return(false);
   if(!Safety_History(why))      return(false);
   return(true);
  }

//--- Light check, on every tick while a signal is pending
bool Safety_Quick(string &why)
  {
   if(!Safety_IsDemoAccount())
     { why = "Account is NOT a verified DEMO account. Trading refused."; return(false); }
   return(Safety_TradeAllowed(why));
  }

//--- Current spread in points
int Safety_SpreadPoints()
  {
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0)
      return(INT_MAX);
   return((int)MathRound((ask - bid) / _Point));
  }

#endif
