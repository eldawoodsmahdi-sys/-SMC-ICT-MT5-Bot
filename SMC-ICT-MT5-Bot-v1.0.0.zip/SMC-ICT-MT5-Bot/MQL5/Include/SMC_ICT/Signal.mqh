//+------------------------------------------------------------------+
//|                                                    Signal.mqh    |
//|  H1 bias + M15 setup engine:                                     |
//|  liquidity sweep -> structure break (BOS/CHOCH/MSS) -> retrace   |
//|  into OB/FVG in discount (buy) / premium (sell) -> rejection bar |
//|  Everything is evaluated on CLOSED candles only.                 |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_SIGNAL_MQH
#define SMC_ICT_SIGNAL_MQH

int g_hEmaFast = INVALID_HANDLE;
int g_hEmaSlow = INVALID_HANDLE;

//--- names for logging
string Signal_DirName(const int dir)   { return(dir > 0 ? "BUY" : "SELL"); }
string Signal_ZoneName(const int t)    { return(t == 1 ? "OB" : "FVG"); }
string Signal_SrcName(const int t, const int dir)
  {
   if(t == 2) return(dir > 0 ? "PDL" : "PDH");
   return(dir > 0 ? "SSL-swing" : "BSL-swing");
  }
string Signal_BreakName(const int t)
  {
   if(t == 1) return("CHOCH");
   if(t == 2) return("BOS");
   return("RANGE-BREAK");
  }

//--- indicator handles
bool Signal_Init()
  {
   g_hEmaFast = iMA(_Symbol, LOCKED_BIAS_TF, LOCKED_EMA_FAST, 0, MODE_EMA, PRICE_CLOSE);
   g_hEmaSlow = iMA(_Symbol, LOCKED_BIAS_TF, LOCKED_EMA_SLOW, 0, MODE_EMA, PRICE_CLOSE);
   if(g_hEmaFast == INVALID_HANDLE || g_hEmaSlow == INVALID_HANDLE)
     {
      LogError(StringFormat("Cannot create EMA handles (error %d).", GetLastError()));
      return(false);
     }
   return(true);
  }

void Signal_Deinit()
  {
   if(g_hEmaFast != INVALID_HANDLE) IndicatorRelease(g_hEmaFast);
   if(g_hEmaSlow != INVALID_HANDLE) IndicatorRelease(g_hEmaSlow);
   g_hEmaFast = INVALID_HANDLE;
   g_hEmaSlow = INVALID_HANDLE;
  }

//--- duplicate-setup memory (persisted in terminal global variables)
string Signal_GVName(const int dir)
  {
   return(StringFormat("%s_%s_%d_%s", SMC_EA_NAME, _Symbol, LOCKED_MAGIC, (dir > 0 ? "B" : "S")));
  }

datetime Signal_LastTraded(const int dir)
  {
   string nm = Signal_GVName(dir);
   if(GlobalVariableCheck(nm))
      return((datetime)(long)GlobalVariableGet(nm));
   return(0);
  }

bool Signal_AlreadyTraded(const int dir, const datetime sweepTime)
  {
   return(sweepTime <= Signal_LastTraded(dir));
  }

void Signal_MarkTraded(const int dir, const datetime sweepTime)
  {
   GlobalVariableSet(Signal_GVName(dir), (double)sweepTime);
  }

void Signal_ResetState()
  {
   GlobalVariableDel(Signal_GVName(1));
   GlobalVariableDel(Signal_GVName(-1));
  }

//+------------------------------------------------------------------+
//| H1 directional bias: +1 buy only, -1 sell only, 0 no trade.      |
//| EMA50/EMA200 alignment on the last closed H1 bar, and (optional) |
//| H1 swing structure must not contradict it.                       |
//+------------------------------------------------------------------+
int Signal_H1Bias(string &info)
  {
   info = "";
   if(BarsCalculated(g_hEmaFast) < 250 || BarsCalculated(g_hEmaSlow) < 250)
     { info = "H1 EMA not calculated yet"; return(0); }

   double ef[], es[];
   ArraySetAsSeries(ef, true);
   ArraySetAsSeries(es, true);
   if(CopyBuffer(g_hEmaFast, 0, 1, 1, ef) != 1 || CopyBuffer(g_hEmaSlow, 0, 1, 1, es) != 1)
     { info = "H1 EMA copy failed"; return(0); }

   double c1 = iClose(_Symbol, LOCKED_BIAS_TF, 1);
   if(c1 <= 0.0)
     { info = "H1 close unavailable"; return(0); }

   int bias = 0;
   if(ef[0] > es[0] && c1 > es[0])      bias = 1;
   else if(ef[0] < es[0] && c1 < es[0]) bias = -1;
   if(bias == 0)
     { info = "H1 EMA bias neutral"; return(0); }

   string lbl = "off";
   if(g_cfg.useH1Structure)
     {
      MqlRates h[];
      ArraySetAsSeries(h, true);
      int got = CopyRates(_Symbol, LOCKED_BIAS_TF, 0, 300, h);
      if(got < 100)
        { info = "H1 history too short"; return(0); }
      SSwing hs[];
      Struct_CollectSwings(h, got, g_cfg.swingStrength, hs);
      int tr = Struct_Trend(hs, 0, lbl);
      if(tr == -bias)
        {
         info = StringFormat("EMA bias %s conflicts with H1 structure %s", Signal_DirName(bias), lbl);
         return(0);
        }
     }
   info = StringFormat("H1 bias %s (EMA50 %.5f, EMA200 %.5f, structure %s)",
                       Signal_DirName(bias), ef[0], es[0], lbl);
   return(bias);
  }

//+------------------------------------------------------------------+
//| Does the last closed bar (shift 1) trigger an entry from zone z? |
//+------------------------------------------------------------------+
bool Signal_ZoneTrigger(const MqlRates &r[], const int dir, const SZone &z, const double eq)
  {
   // 1) last closed bar must trade into the zone
   bool touch = (dir > 0) ? (r[1].low <= z.high) : (r[1].high >= z.low);
   if(!touch)
      return(false);

   // 2) first retest only
   if(g_cfg.firstTouchOnly && Zone_TouchedBetween(r, dir, z, z.formShift - 1, 2))
      return(false);

   // 3) rejection candle: closes in trade direction and not through the zone
   if(dir > 0)
     {
      if(!(r[1].close > r[1].open && r[1].close >= z.low))
         return(false);
     }
   else
     {
      if(!(r[1].close < r[1].open && r[1].close <= z.high))
         return(false);
     }

   // 4) premium / discount filter
   double mid = 0.5 * (z.low + z.high);
   if(dir > 0 && mid > eq) return(false);
   if(dir < 0 && mid < eq) return(false);
   return(true);
  }

//+------------------------------------------------------------------+
//| Build the most recent valid setup in direction 'dir'.            |
//+------------------------------------------------------------------+
bool Signal_BuildSetup(const MqlRates &r[], const int total, const SSwing &sw[],
                       const int dir, SSignal &sig)
  {
   const int n    = g_cfg.swingStrength;
   const int maxS = g_cfg.setupMaxAgeBars;
   const int nsw  = ArraySize(sw);

   for(int s = 2; s <= maxS && s < total - (2 * n) - 5; s++)
     {
      //--- 1) liquidity sweep on closed bar s
      double level = 0.0;
      int    src   = 0;
      if(!Liq_FindSweep(r, total, sw, dir, s, level, src))
         continue;
      if(Signal_AlreadyTraded(dir, r[s].time))
         continue;

      //--- 2) reference swing: nearest opposite swing older than the sweep bar
      int refIdx = -1;
      for(int i = nsw - 1; i >= 0; i--)
        {
         if(sw[i].dir == dir && sw[i].shift > s)
           { refIdx = i; break; }
        }
      if(refIdx < 0)
         continue;
      double refPrice = sw[refIdx].price;
      if(sw[refIdx].shift - s > REF_MAX_DISTANCE)
         continue;

      //--- 3) first CLOSE beyond the reference swing after the sweep
      int m = -1;
      for(int k = s - 1; k >= 1; k--)
        {
         if((dir > 0 && r[k].close > refPrice) || (dir < 0 && r[k].close < refPrice))
           { m = k; break; }
        }
      if(m < 2)                       // not found, or break is the last closed bar
         continue;

      //--- 4) impulse-leg extreme between sweep and break
      int    legShift = s;
      double legPrice = (dir > 0) ? r[s].low : r[s].high;
      for(int k = s - 1; k >= m; k--)
        {
         if(dir > 0 && r[k].low < legPrice)  { legPrice = r[k].low;  legShift = k; }
         if(dir < 0 && r[k].high > legPrice) { legPrice = r[k].high; legShift = k; }
        }

      //--- 5) setup is dead if the leg extreme was taken after the break
      bool dead = false;
      for(int k = m - 1; k >= 1; k--)
        {
         if((dir > 0 && r[k].low < legPrice) || (dir < 0 && r[k].high > legPrice))
           { dead = true; break; }
        }
      if(dead)
         continue;

      //--- 6) displacement (MSS quality) and break classification
      bool   disp = false;
      double atr  = Struct_AtrAt(r, total, m, ATR_PERIOD);
      if(atr > 0.0)
        {
         for(int k = legShift; k >= m; k--)
           {
            double body = (dir > 0) ? (r[k].close - r[k].open) : (r[k].open - r[k].close);
            if(body >= g_cfg.displacementAtr * atr)
              { disp = true; break; }
           }
        }
      if(g_cfg.requireDisplacement && !disp)
         continue;

      string lbl;
      int priorTrend = Struct_Trend(sw, s, lbl);
      int bt = 3;                                   // range break
      if(priorTrend == -dir)      bt = 1;           // CHOCH
      else if(priorTrend == dir)  bt = 2;           // BOS

      //--- 7) points of interest
      SZone zs[2];
      zs[0].valid = false;
      zs[1].valid = false;
      Zone_FindOB(r, total, dir, legShift, m, zs[0]);
      Zone_FindFVG(r, dir, legShift, m, zs[1]);
      if(!zs[0].valid && !zs[1].valid)
         continue;

      //--- 8) dealing range -> equilibrium
      double rangeLow, rangeHigh;
      if(dir > 0)
        {
         rangeLow  = legPrice;
         rangeHigh = r[1].high;
         for(int k = 2; k <= legShift; k++)
            if(r[k].high > rangeHigh) rangeHigh = r[k].high;
        }
      else
        {
         rangeHigh = legPrice;
         rangeLow  = r[1].low;
         for(int k = 2; k <= legShift; k++)
            if(r[k].low < rangeLow) rangeLow = r[k].low;
        }
      double eq = 0.5 * (rangeHigh + rangeLow);

      //--- 9) retest trigger on the last closed bar
      int use = -1;
      for(int zi = 0; zi < 2; zi++)
        {
         if(!zs[zi].valid)
            continue;
         if(Signal_ZoneTrigger(r, dir, zs[zi], eq))
           { use = zi; break; }
        }
      if(use < 0)
         continue;

      //--- fill signal
      ZeroMemory(sig);
      sig.valid        = true;
      sig.dir          = dir;
      sig.detectBar    = r[1].time;
      sig.sweepTime    = r[s].time;
      sig.sweptLevel   = level;
      sig.sweepSrc     = src;
      sig.breakType    = bt;
      sig.displacement = disp;
      sig.invalidation = legPrice;
      sig.zoneLow      = zs[use].low;
      sig.zoneHigh     = zs[use].high;
      sig.zoneType     = zs[use].type;
      sig.rangeLow     = rangeLow;
      sig.rangeHigh    = rangeHigh;
      sig.breakAge     = m;
      return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Entry point: scan M15 for a setup in the direction of H1 bias.   |
//+------------------------------------------------------------------+
bool Signal_Detect(const int bias, SSignal &sig)
  {
   ZeroMemory(sig);
   sig.valid = false;

   MqlRates r[];
   ArraySetAsSeries(r, true);
   int total = CopyRates(_Symbol, LOCKED_ENTRY_TF, 0, g_cfg.scanBars, r);
   if(total < MIN_SCAN_BARS)
     {
      LogWarn(StringFormat("Insufficient M15 data: copied %d bars (need %d).", total, MIN_SCAN_BARS));
      return(false);
     }

   SSwing sw[];
   int nsw = Struct_CollectSwings(r, total, g_cfg.swingStrength, sw);
   if(nsw < 4)
     {
      LogDebug("Not enough M15 swings.");
      return(false);
     }
   return(Signal_BuildSetup(r, total, sw, bias, sig));
  }

#endif
