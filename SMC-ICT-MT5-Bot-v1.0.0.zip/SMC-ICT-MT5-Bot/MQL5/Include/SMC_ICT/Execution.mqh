//+------------------------------------------------------------------+
//|                                                  Execution.mqh   |
//|  Order placement with full pre-trade validation.                 |
//+------------------------------------------------------------------+
#ifndef SMC_ICT_EXECUTION_MQH
#define SMC_ICT_EXECUTION_MQH

#include <Trade/Trade.mqh>

#define EXEC_OK      0
#define EXEC_RETRY   1   // transient (spread, requote): try again on a later tick of the same bar
#define EXEC_REJECT  2   // permanent for this setup

CTrade g_trade;

void Exec_Init()
  {
   g_trade.SetExpertMagicNumber(LOCKED_MAGIC);
   g_trade.SetDeviationInPoints(g_cfg.deviationPoints);
   g_trade.SetTypeFillingBySymbol(_Symbol);
   g_trade.SetAsyncMode(false);
  }

int Exec_TryOpen(const SSignal &sig, string &why)
  {
   MqlTick tk;
   if(!SymbolInfoTick(_Symbol, tk) || tk.bid <= 0.0 || tk.ask <= 0.0)
     { why = "No valid tick."; return(EXEC_RETRY); }
   double bid = tk.bid;
   double ask = tk.ask;

   //--- spread filter (transient)
   int spread = (int)MathRound((ask - bid) / _Point);
   if(spread > g_cfg.maxSpreadPoints)
     {
      why = StringFormat("Spread %d pts > max %d pts.", spread, g_cfg.maxSpreadPoints);
      return(EXEC_RETRY);
     }

   //--- structural invalidation already taken?
   if(sig.dir > 0 && bid <= sig.invalidation)
     { why = "Price already beyond structural invalidation."; return(EXEC_REJECT); }
   if(sig.dir < 0 && ask >= sig.invalidation)
     { why = "Price already beyond structural invalidation."; return(EXEC_REJECT); }

   //--- SL from structure, TP = 2R from the actual entry price
   double buffer = g_cfg.slBufferPoints * _Point;
   double entry, sl, tp;
   if(sig.dir > 0)
     {
      entry = ask;
      sl    = sig.invalidation - buffer;
     }
   else
     {
      entry = bid;
      sl    = sig.invalidation + buffer + (ask - bid);   // sells close on ask
     }
   sl = NormalizeDouble(sl, _Digits);
   double risk = MathAbs(entry - sl);
   tp = (sig.dir > 0) ? entry + LOCKED_RR * risk : entry - LOCKED_RR * risk;
   tp = NormalizeDouble(tp, _Digits);

   //--- broker stop distances + SL sanity
   if(!Risk_ValidateStops(sig.dir, bid, ask, entry, sl, tp, why))
      return(EXEC_REJECT);

   //--- lot size from actual SL distance (0.5% risk, rounded down)
   double lots, riskMoney, riskPct;
   if(!Risk_CalcLots(sig.dir, entry, sl, lots, riskMoney, riskPct, why))
      return(EXEC_REJECT);

   //--- send
   string comment = (sig.dir > 0) ? "SMC-ICT B" : "SMC-ICT S";
   bool sent = (sig.dir > 0) ? g_trade.Buy(lots, _Symbol, 0.0, sl, tp, comment)
                             : g_trade.Sell(lots, _Symbol, 0.0, sl, tp, comment);
   uint rc = g_trade.ResultRetcode();

   if(sent && (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL))
     {
      LogInfo(StringFormat("OPENED %s %.2f lots @ %.5f | SL %.5f | TP %.5f | risk %.2f %s (%.3f%%) | spread %d pts",
                           Signal_DirName(sig.dir), lots, entry, sl, tp,
                           riskMoney, AccountInfoString(ACCOUNT_CURRENCY), riskPct, spread));
      return(EXEC_OK);
     }

   why = StringFormat("Order failed: retcode %u (%s)", rc, g_trade.ResultRetcodeDescription());
   if(rc == TRADE_RETCODE_REQUOTE || rc == TRADE_RETCODE_PRICE_CHANGED ||
      rc == TRADE_RETCODE_PRICE_OFF || rc == TRADE_RETCODE_TOO_MANY_REQUESTS)
      return(EXEC_RETRY);
   return(EXEC_REJECT);
  }

#endif
